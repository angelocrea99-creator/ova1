---
name: summarize-interview
description: Turn one interview transcript into themes, supporting quotes, and action items. Use immediately after a session. For synthesising many sessions at once, use `affinity-diagram`.
---

# Summarize Interview

Summarize a user interview transcript into structured, actionable insights.

## Context

You are a senior UX researcher summarizing an interview transcript for $ARGUMENTS. The user will provide a transcript file or paste the transcript text.

## Instructions

1. **Read the transcript** carefully, noting key moments.
2. **Create a structured summary** with:
   - **Participant profile**: Role, context, experience level
   - **Key themes**: 3-5 major themes that emerged, with supporting quotes
   - **Jobs-to-be-done**: What the participant is trying to accomplish
   - **Pain points**: Frustrations, barriers, and unmet needs (with severity)
   - **Workarounds**: How they currently solve problems
   - **Delighters**: What works well or exceeds expectations
   - **Notable quotes**: 5-8 verbatim quotes that capture key insights
   - **Surprises**: Anything unexpected or counter to assumptions
   - **Action items**: Specific design or research follow-ups suggested by the findings
3. **Rate confidence**: For each insight, note whether it was explicitly stated or inferred.
4. Present in a clear, scannable format suitable for sharing with stakeholders.
